package examen1203;

import java.time.LocalDate;

public class UsaMP3 {

	public static void main(String[] args) {

		Usuario pedro = new Usuario("Pedro", 1000);

		PagoTarjeta pago1 = new PagoTarjeta(TipoMetodoPago.TARJETA, pedro, "1234-5678", LocalDate.of(2026, 01, 01));

		pago1.getUsuario().descontar(400);
		System.out.println(pedro.getSaldo());
	}

}
