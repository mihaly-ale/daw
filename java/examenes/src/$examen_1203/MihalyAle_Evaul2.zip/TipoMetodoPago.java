package examen1203;

public enum TipoMetodoPago {

	TARJETA(2.5, "tarjeta"),TRANSFERENCIA(1, "transferencia"), PAYPAL(3.2, "paypal");
	
	double comision;
	String modoPago;

	// const
	private TipoMetodoPago(double comision, String modoPago) {
		this.comision = comision;
		this.modoPago = modoPago;
	}

	//getter
	public double getComision() {
		return comision;
	}
	
	public String getModoPago() {
		return modoPago;
	}	
	
	//metodos
	public double calcularTotal(double importe) {
		importe += importe * comision/100;	
		System.out.printf("%.2f", importe);
		return importe;
	}	
}
