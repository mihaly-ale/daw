package examen1203;

import java.time.LocalDate;

public class PagoTarjeta extends MetodoPago {
	
	private String numeroTarjeta;
	private LocalDate fechaCaucidad;	
	
	// constr
	public PagoTarjeta(TipoMetodoPago tipoMp, Usuario usuario, String numeroTarjeta, LocalDate fechaCaucidad) {
		super(tipoMp, usuario);
		this.numeroTarjeta = numeroTarjeta;
		this.fechaCaucidad = fechaCaucidad;
	}

	@Override
	void pagar(double cantidad) {
		LocalDate hoy = LocalDate.now();
//		System.out.println("here");
		
		if (hoy.isBefore(getFechaCaucidad())) {
//			System.out.println("paga");
			getUsuario().descontar(cantidad);
		}
		
	}
	

	@Override
	boolean comprrobarSaldo(double cantidad) {
		super.getUsuario().tieneSaldoSuficiente(cantidad);
		// TODO Auto-generated method stub
		return false;
	}

	//getters, setters
	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public LocalDate getFechaCaucidad() {
		return fechaCaucidad;
	}

	public void setFechaCaucidad(LocalDate fechaCaucidad) {
		this.fechaCaucidad = fechaCaucidad;
	}
	
	
}


