package examen1203;

abstract class MetodoPago {

	private TipoMetodoPago tipoMp;
	private Usuario usuario;	
 
	// const
	public MetodoPago(TipoMetodoPago tipoMp, Usuario usuario) {
		this.tipoMp = tipoMp;
		this.usuario = usuario;
	}	
	
	abstract void pagar(double cantidad);
	abstract boolean comprrobarSaldo(double cantidad);

	public TipoMetodoPago getTipoMp() {
		return tipoMp;
	}

	public void setTipoMp(TipoMetodoPago tipoMp) {
		this.tipoMp = tipoMp;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	
	
	

}
