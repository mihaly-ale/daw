package examen1203;

import java.time.LocalDate;

public class PagoTransferencia extends MetodoPago {

	private String ibanDestino;

	//constr
	public PagoTransferencia(TipoMetodoPago tipoMp, Usuario usuario, String ibanDestino) {
		super(tipoMp, usuario);
		this.ibanDestino = ibanDestino;
	}

	@Override
	void pagar(double cantidad) {
		LocalDate hoy = LocalDate.now();
//		System.out.println("here");
		
		if (hoy.isBefore(super.getFechaCaucidad())) {
//			System.out.println("paga");
			getUsuario().descontar(cantidad);
		}
		
	}

	@Override
	boolean comprrobarSaldo(double cantidad) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
}
